﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace SWTCourseWork
{
    public partial class Form1 : Form
    {
        private Bitmap bmIn;
        private Bitmap bmOut;
        private Bitmap bmOg;
        
        private int w, h, matrix, charCount, pixelIntensity;
        private Graphics gr;
        private string text;
        private char[] sym;
        private Font my;
        

        private void GetText()
        {
            text = textBox1.Text;
            text = text.ToUpper();
            text = text.Replace(" ", "");
            sym = text.ToCharArray();
        }

        private int Counter(int c)
        {
            if (c < sym.Length - 1)
            {
                c++;
            }
            else
            {
                c = 0;
            }
            return c;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (my != null)
            {
                my.Dispose();
            }
            this.Close();

        }

        private void filteredImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                if (textBox1.Text != "")
                {
                    GetText();
                    bmOut = new Bitmap(w, h);
                    gr = Graphics.FromImage(bmOut);
                    gr.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixel;
                    for (int j = 0; j < h; j += matrix)
                    {
                        charCount = 0;
                        for (int i = 0; i < w; i += matrix)
                        {
                            pixelIntensity = bmIn.GetPixel(i, j).R;
                            if (pixelIntensity >= 0 && pixelIntensity < 63)
                            {
                                gr.DrawString(sym[charCount].ToString(), my, Brushes.Black, i, j);
                                charCount = Counter(charCount);
                            }
                            else
                                if (pixelIntensity >= 63 && pixelIntensity < 127)
                            {
                                using (Font my1 = new Font("Ariel", 12, FontStyle.Regular))
                                {
                                    gr.DrawString(sym[charCount].ToString(), my1, Brushes.Black, i, j);
                                    charCount = Counter(charCount);
                                }
                            }
                            else
                                    if (pixelIntensity >= 127 && pixelIntensity < 190)
                            {
                                using (Font my2 = new Font("Ariel", 10, FontStyle.Regular))
                                {
                                    gr.DrawString(sym[charCount].ToString(), my2, Brushes.Black, i, j);
                                    charCount = Counter(charCount);
                                }
                            }
                            else
                                        if (pixelIntensity >= 190 && pixelIntensity < 256)
                            {
                                using (Font my3 = new Font("Ariel", 8, FontStyle.Regular))
                                {
                                    gr.DrawString(sym[charCount].ToString(), my3, Brushes.Black, i, j);
                                    charCount = Counter(charCount);
                                }
                            }
                        }
                    }
                    pictureBox1.Image = bmOut;
                }
                else
                {
                    MessageBox.Show("Please, enter text for screening!!!");
                }
            }
            else
            {
                MessageBox.Show("Please, load an image.");
            }

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "JPEG files (*.jpeg)|*.jpeg|Bitmap files (*.bmp)|*.bmp|JPG files (*.jpg)|*.jpg|GIF files(*.gif) | *.gif | All files(*.*) | *.* ";
            save.FilterIndex = 4;
            save.RestoreDirectory = true;

            if (save.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image.Save(save.FileName);
            }
        }



        private void filteredImageToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            if (pictureBox1.Image != null) {
                Bitmap bmpNew = GetArgbCopy(pictureBox1.Image);
                BitmapData bmpData = bmpNew.LockBits(new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);


                IntPtr ptr = bmpData.Scan0;


                byte[] byteBuffer = new byte[bmpData.Stride * bmpNew.Height];


                Marshal.Copy(ptr, byteBuffer, 0, byteBuffer.Length);


                float rgb = 0;


                for (int k = 0; k < byteBuffer.Length; k += 4)
                {
                    rgb = byteBuffer[k] * 0.11f;
                    rgb += byteBuffer[k + 1] * 0.59f;
                    rgb += byteBuffer[k + 2] * 0.3f;


                    byteBuffer[k] = (byte)rgb;
                    byteBuffer[k + 1] = byteBuffer[k];
                    byteBuffer[k + 2] = byteBuffer[k];


                    byteBuffer[k + 3] = 255;
                }


                Marshal.Copy(byteBuffer, 0, ptr, byteBuffer.Length);


                bmpNew.UnlockBits(bmpData);


                bmpData = null;
                byteBuffer = null;


                pictureBox1.Image= bmpNew;
            }
            else
            {
                MessageBox.Show("Please, load an image.");
            }
        }

        private void filteredImageToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {

                Bitmap bmpNew = GetArgbCopy(pictureBox1.Image);
                BitmapData bmpData = bmpNew.LockBits(new Rectangle(0, 0, pictureBox1.Image.Width, pictureBox1.Image.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);


            IntPtr ptr = bmpData.Scan0;


            byte[] byteBuffer = new byte[bmpData.Stride * bmpNew.Height];


            Marshal.Copy(ptr, byteBuffer, 0, byteBuffer.Length);


            byte maxValue = 255;
            float r = 0;
            float g = 0;
            float b = 0;

            
                
                {

                    for (int k = 0; k < byteBuffer.Length; k += 4)
                    {
                        r = byteBuffer[k] * 0.189f + byteBuffer[k + 1] * 0.769f + byteBuffer[k + 2] * 0.393f;
                        g = byteBuffer[k] * 0.168f + byteBuffer[k + 1] * 0.686f + byteBuffer[k + 2] * 0.349f;
                        b = byteBuffer[k] * 0.131f + byteBuffer[k + 1] * 0.534f + byteBuffer[k + 2] * 0.272f;


                        byteBuffer[k + 2] = (r > maxValue ? maxValue : (byte)r);
                        byteBuffer[k + 1] = (g > maxValue ? maxValue : (byte)g);
                        byteBuffer[k] = (b > maxValue ? maxValue : (byte)b);
                    }


                    Marshal.Copy(byteBuffer, 0, ptr, byteBuffer.Length);


                    bmpNew.UnlockBits(bmpData);


                    bmpData = null;
                    byteBuffer = null;


                    pictureBox1.Image = bmpNew;

                }
            }
            else
            {
                MessageBox.Show("Please, load an image.");
            }
        }
     

        private void showOriginalImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = bmOg;
  
        }

        private void clearImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }

        private void filterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                Bitmap bmpNew = GetArgbCopy(pictureBox1.Image);
                BitmapData bmpData = bmpNew.LockBits(new Rectangle(0, 0, pictureBox1.Image.Width, pictureBox1.Image.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);


            IntPtr ptr = bmpData.Scan0;


            byte[] byteBuffer = new byte[bmpData.Stride * bmpNew.Height];


            Marshal.Copy(ptr, byteBuffer, 0, byteBuffer.Length);
            byte[] pixelBuffer = null;


            int pixel = 0;


            for (int k = 0; k < byteBuffer.Length; k += 4)
            {
                pixel = ~BitConverter.ToInt32(byteBuffer, k);
                pixelBuffer = BitConverter.GetBytes(pixel);


                byteBuffer[k] = pixelBuffer[0];
                byteBuffer[k + 1] = pixelBuffer[1];
                byteBuffer[k + 2] = pixelBuffer[2];
            }


            Marshal.Copy(byteBuffer, 0, ptr, byteBuffer.Length);


            bmpNew.UnlockBits(bmpData);


            bmpData = null;
            byteBuffer = null;


            pictureBox1.Image = bmpNew;
        }
            else
            {
                MessageBox.Show("Please, load an image.");
            }

      }

        

        public Form1()
        {
            InitializeComponent();
            matrix = 5;
            charCount = 0;
            my = new Font("Ariel", 14, FontStyle.Regular, GraphicsUnit.Pixel);

        }

        

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog load = new OpenFileDialog();
            load.Filter = "JPEG files (*.jpeg)|*.jpeg|Bitmap files (*.bmp)|*.bmp|JPG files (*.jpg)|*.jpg|GIF files(*.gif) | *.gif | All files(*.*) | *.* ";
            load.FilterIndex = 4;
            load.RestoreDirectory = true;

            if (load.ShowDialog() == DialogResult.OK)
            {
                bmIn = new Bitmap(Image.FromFile(load.FileName));
                w = bmIn.Width;
                h = bmIn.Height;
                pictureBox1.Size = new Size(w, h);

                pictureBox1.Image = bmIn;
                bmOg = bmIn;

            }


        }

        private static Bitmap GetArgbCopy(Image sourceImage)
        {
           
                Bitmap bmpNew = new Bitmap(sourceImage.Width, sourceImage.Height, PixelFormat.Format32bppArgb);


                using (Graphics graphics = Graphics.FromImage(bmpNew))
                {
                    graphics.DrawImage(sourceImage, new Rectangle(0, 0, bmpNew.Width, bmpNew.Height), new Rectangle(0, 0, bmpNew.Width, bmpNew.Height), GraphicsUnit.Pixel);
                    graphics.Flush();
                }
                return bmpNew;
            
            
        }
    }
}
